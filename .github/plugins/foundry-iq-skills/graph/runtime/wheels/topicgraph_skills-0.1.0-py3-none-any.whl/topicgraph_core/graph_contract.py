"""The TopicGraph build tool's output contract this toolkit reads: the topic form only.

The pinned tool writes run manifest v2 (`structures[].topics`), sealed structure v3 and the `topicgraph-topic`
graph with ontology 2.3.0 and semantic configuration `topicgraph-topic-semantic`. Anything else is rejected.
Contracts are chosen by explicit version or graph name, never by producer version.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .contracts import ContractError


@dataclass(frozen=True)
class GraphVocabulary:
    graph_name: str
    ontology_version: str
    graph_prefix: str  # subject ID of the graph root: <prefix><graph_name>
    topic_prefix: str  # topic IDs: <prefix><integer>
    root: str
    child: str
    graph_type: str
    topic_type: str
    semantic_configuration: str


TOPIC_FORM = GraphVocabulary("topicgraph-topic", "2.3.0", "topicgraph:", "topic:", "HasRootTopic", "HasSubTopic",
                             "TopicGraph", "Topic", "topicgraph-topic-semantic")
RUN_MANIFEST_VERSION = 2
RUN_MANIFEST_TOPICS = "topics"


def graph_vocabulary(documents: list[dict[str, Any]]) -> GraphVocabulary | None:
    """TOPIC_FORM when every document is a consistent topic-form graph row; None otherwise."""
    try:
        return check_topic_graph(documents)
    except ContractError:
        return None


def check_topic_graph(documents: list[dict[str, Any]]) -> GraphVocabulary:
    """Require every document to be a topic-form row; anything else fails closed."""
    form = TOPIC_FORM
    if not documents:
        raise ContractError("TOPIC_INDEX_INVALID", "The topic index has no graph documents")
    names = {doc.get("graph_name") for doc in documents}
    if names != {form.graph_name}:
        raise ContractError("TOPIC_INDEX_INVALID", f"The topic index documents must all name the {form.graph_name} "
                            f"graph; found {sorted(map(str, names))}")
    for doc in documents:
        for id_key, type_key in (("subject_id", "subject_type"), ("object_id", "object_type")):
            value, kind = doc.get(id_key), doc.get(type_key)
            if isinstance(value, str) and value.startswith(form.topic_prefix) and kind != form.topic_type:
                raise ContractError("TOPIC_INDEX_INVALID", f"{value} must have type {form.topic_type}, not {kind!r}")
            if isinstance(value, str) and value.startswith(form.graph_prefix) and kind != form.graph_type:
                raise ContractError("TOPIC_INDEX_INVALID", f"{value} must have type {form.graph_type}, not {kind!r}")
    return form


def check_semantic_configuration(schema: dict[str, Any]) -> None:
    """The release schema's default semantic configuration must be the topic-form one."""
    semantic = schema.get("semantic") if isinstance(schema, dict) else None
    names = [c.get("name") for c in (semantic or {}).get("configurations") or [] if isinstance(c, dict)]
    default = (semantic or {}).get("defaultConfiguration")
    if default != TOPIC_FORM.semantic_configuration or names != [TOPIC_FORM.semantic_configuration]:
        raise ContractError("RELEASE_INVALID", "The release schema must define exactly the "
                            f"{TOPIC_FORM.semantic_configuration} semantic configuration as its default")
