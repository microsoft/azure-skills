"""Offline route decisions and read-only, exact-resource preflight."""

from __future__ import annotations

import re
from typing import Any, Protocol

from ekg_core.content_understanding import region_supported, region_warning
from ekg_core.models import (
    CACHE_USES_SYSTEM_ASSIGNED_IDENTITY, BuildSpec, Event, KnowledgeSourceKind,
    PreflightResult, RequestedOutcome, RouteDecision, SourceKind,
)

from .managed_pipeline import (
    content_understanding_error, search_api_version, uses_content_understanding,
    uses_direct_blob_source,
)
from .target_validation import graph_input_error, search_resource_id
from .target_reader import canonical_resource_endpoint


class ResourceReader(Protocol):
    def inspect_search_service(self, resource_id: str, tenant_id: str) -> dict[str, Any]: ...
    def inspect_resource(self, resource_id: str, tenant_id: str) -> dict[str, Any]: ...


_ARM_ID = re.compile(
    r"/subscriptions/([0-9a-fA-F-]{36})/resourceGroups/([^/]+)/"
    r"providers/(Microsoft\.[^/]+)/([^/]+)/([^/]+)", re.IGNORECASE,
)
_GUID = re.compile(r"[0-9a-fA-F]{8}(?:-[0-9a-fA-F]{4}){3}-[0-9a-fA-F]{12}")
SOFT_DELETE_DOC = ("https://learn.microsoft.com/en-us/azure/storage/blobs/"
                   "soft-delete-blob-enable?tabs=azure-portal")
STORAGE_ARM_API_VERSION = "2024-01-01"


def blob_soft_delete(arm: Any, spec: BuildSpec) -> tuple[str, str | None] | None:
    """Read-only check of the Blob source's soft delete; None when it does not apply.

    The managed data source detects deleted blobs only through soft delete, so a blob
    removed from the source prefix outside `update` otherwise stays in the indexes.
    """
    source = spec.source
    if (arm is None or not hasattr(arm, "arm_read") or not uses_direct_blob_source(spec)
            or source is None or not spec.tenant_id):
        return None
    parsed = _identity(source.resource_id, "Microsoft.Storage", "storageAccounts")
    if parsed is None:
        return None
    subscription, group, account = parsed
    enable = (f"az storage account blob-service-properties update --account-name {account} "
              f"--resource-group {group} --subscription {subscription} "
              "--enable-delete-retention true --delete-retention-days 7")
    try:
        observed = arm.arm_read(f"{source.resource_id}/blobServices/default",
                                STORAGE_ARM_API_VERSION, tenant_id=spec.tenant_id)
        policy = observed["properties"].get("deleteRetentionPolicy") or {}
    except Exception:  # denied, missing or malformed: report unknown, never fail
        return ("unknown",
                f"BLOB_SOFT_DELETE_UNKNOWN: could not read blob soft delete on storage account "
                f"{account}. Documents deleted from the source prefix are removed from the index "
                f"only when soft delete is on; check it, or turn it on with: {enable} "
                f"(see {SOFT_DELETE_DOC}).")
    if policy.get("enabled") is True:
        return ("enabled", None)
    return ("disabled",
            f"BLOB_SOFT_DELETE_OFF: blob soft delete is off on storage account {account}, so "
            "documents deleted from the source prefix stay in the index. Turn it on before any "
            f"deletions occur: {enable} (see {SOFT_DELETE_DOC}).")


COGNITIVE_ARM_API_VERSION = "2024-10-01"
CONTENT_UNDERSTANDING_DOC = ("https://learn.microsoft.com/en-us/azure/search/"
                             "agentic-knowledge-source-how-to-blob")


def _subdomain(endpoint: str | None) -> str | None:
    match = re.fullmatch(r"https://([^./]+)\.[^/]+/?", endpoint or "", re.IGNORECASE)
    return match[1].casefold() if match else None


def _content_understanding_account(arm: Any, spec: BuildSpec) -> str | None:
    """ARM ID of the account behind the CU endpoint; reads only, None when not found."""
    wanted = _subdomain(spec.target.content_understanding_endpoint)
    target = spec.target
    known = [(target.openai_resource_id, target.openai_endpoint),
             (target.embedding_openai_resource_id, target.effective_embedding_openai_endpoint),
             (target.chat_openai_resource_id, target.effective_chat_openai_endpoint),
             (target.kb_openai_resource_id, target.effective_kb_openai_endpoint)]
    subscriptions: list[str] = [target.subscription_id] if target.subscription_id else []
    for resource_id, endpoint in known:
        parsed = _identity(resource_id, "Microsoft.CognitiveServices", "accounts")
        if parsed is None:
            continue
        if _subdomain(endpoint) == wanted:
            return resource_id
        if parsed[0] not in subscriptions:
            subscriptions.append(parsed[0])
    for subscription in subscriptions:
        listed = arm.arm_read(f"/subscriptions/{subscription}/providers/"
                              "Microsoft.CognitiveServices/accounts",
                              COGNITIVE_ARM_API_VERSION, tenant_id=spec.tenant_id) or {}
        for account in listed.get("value") or []:
            properties = account.get("properties") or {}
            name = properties.get("customSubDomainName") or account.get("name")
            if isinstance(name, str) and name.casefold() == wanted:
                return account.get("id")
    return None


def _is_embedding(deployment: dict[str, Any]) -> bool:
    properties = deployment.get("properties") or {}
    capabilities = properties.get("capabilities") or {}
    model = properties.get("model") or {}
    return (str(capabilities.get("embeddings", "")).lower() == "true"
            or "embedding" in str(model.get("name", "")).lower())


def content_understanding_embedding(arm: Any, spec: BuildSpec) -> tuple[str, str | None] | None:
    """Read-only check that the CU account holds an embedding deployment; never creates one.

    Standard content extraction needs an embedding deployment on the Content Understanding
    resource. A chat deployment is needed only with image verbalization, which builds disable.
    Returns None when the check does not apply; status is present, unmatched, missing or unknown.
    """
    if (arm is None or not hasattr(arm, "arm_read") or not spec.tenant_id
            or not uses_content_understanding(spec) or content_understanding_error(spec)):
        return None
    endpoint = spec.target.content_understanding_endpoint
    wanted = spec.embedding_deployment
    named = f" `{wanted}`" if wanted else ""
    try:
        account_id = _content_understanding_account(arm, spec)
        listed = (arm.arm_read(f"{account_id}/deployments", COGNITIVE_ARM_API_VERSION,
                               tenant_id=spec.tenant_id) if account_id else None)
        deployments = listed["value"] if isinstance(listed, dict) else None
        if not isinstance(deployments, list):
            raise ValueError("deployment list is missing or malformed")
    except Exception:  # unresolved, denied or malformed: report unverified, never fail
        return ("unknown",
                "CONTENT_UNDERSTANDING_EMBEDDING_UNVERIFIED: could not read the deployments on "
                f"the Content Understanding account at {endpoint}. Standard content extraction "
                f"needs an embedding model deployment{named} there; confirm it exists "
                f"(see {CONTENT_UNDERSTANDING_DOC}).")
    account = account_id.rsplit("/", 1)[-1]
    embeddings = sorted(str(item.get("name")) for item in deployments
                        if isinstance(item, dict) and _is_embedding(item))
    if not embeddings:
        return ("missing",
                f"CONTENT_UNDERSTANDING_EMBEDDING_MISSING: Content Understanding account "
                f"{account} has no embedding model deployment. Standard content extraction of "
                f"non-text documents needs one. Have the account owner deploy the Build's "
                f"embedding model there{' named' + named if named else ''}, then rerun; this "
                f"skill does not create deployments (see {CONTENT_UNDERSTANDING_DOC}).")
    if wanted and wanted.casefold() not in {name.casefold() for name in embeddings}:
        return ("unmatched",
                f"CONTENT_UNDERSTANDING_EMBEDDING_NAME: Content Understanding account {account} "
                f"has embedding deployments {', '.join(embeddings)} but none named{named}. "
                "If extraction fails, add an embedding deployment with that name.")
    return ("present", None)


ROLE_ARM_API_VERSION = "2022-04-01"
IDENTITY_ARM_API_VERSION = "2023-01-31"
# Built-in roles that let Search call Content Understanding with its managed identity.
CONTENT_UNDERSTANDING_ROLES = {
    "a97b65f3-24c7-4388-baec-2e87135dc908": "Cognitive Services User",
    "25fbc0a9-bd7c-42a3-aa1a-3b75d497ee68": "Cognitive Services Contributor",
    "64702f94-c441-49e6-a78b-ef80e0188fee": "Azure AI Developer",
    "53ca6127-db72-4b80-b1b0-d745d6d5456d": "Azure AI User",
}
# Built-in roles known to lack the Content Understanding data actions.
NOT_CONTENT_UNDERSTANDING_ROLES = frozenset({
    "8e3af657-a8ff-443c-a75c-2fe8c4bcb635",  # Owner
    "b24988ac-6180-42a0-ab88-20f7382dd24c",  # Contributor
    "acdd72a7-3385-48ef-bd42-f606fba81ae7",  # Reader
    "18d7d88d-d35e-4fb5-a5c3-7773c20a72d9",  # User Access Administrator
    "5e0bd9bd-7b93-4f28-af87-19fc36ad61bd",  # Cognitive Services OpenAI User
    "a001fd3d-188f-4b5d-821b-7da978bf7442",  # Cognitive Services OpenAI Contributor
})


def _content_understanding_applies(arm: Any, spec: BuildSpec) -> bool:
    return (arm is not None and hasattr(arm, "arm_read") and bool(spec.tenant_id)
            and uses_content_understanding(spec) and not content_understanding_error(spec))


def _roles_at(arm: Any, spec: BuildSpec, account_id: str, principal: str) -> list[str]:
    """Role definition GUIDs the principal holds at the account scope or above it.

    assignedTo() also returns assignments made to the principal's groups, whose
    principalId is the group, so the results aren't filtered by principal again.
    """
    listed = arm.arm_read(f"{account_id}/providers/Microsoft.Authorization/roleAssignments",
                          ROLE_ARM_API_VERSION, tenant_id=spec.tenant_id,
                          params={"$filter": f"assignedTo('{principal}')"})
    items = listed["value"] if isinstance(listed, dict) else None
    if not isinstance(items, list):
        raise ValueError("role assignment list is missing or malformed")
    account = account_id.casefold()
    roles = []
    for item in items:
        properties = item.get("properties") or {}
        scope = str(properties.get("scope") or "").rstrip("/").casefold()
        # A role on the subscription, resource group or the account itself applies.
        if scope and (account == scope or account.startswith(scope + "/")):
            roles.append(str(properties.get("roleDefinitionId") or "").rsplit("/", 1)[-1]
                         .casefold())
    return roles


def _cache_principal(spec: BuildSpec, search_observed: Any) -> tuple[str, str | None]:
    """(label, principal ID) the enrichment cache authenticates as, read from the Search resource."""
    identity = (search_observed.get("identity") or {}) if isinstance(search_observed, dict) else {}
    identity = identity if isinstance(identity, dict) else {}
    if (CACHE_USES_SYSTEM_ASSIGNED_IDENTITY or not spec.search_identity_resource_id
            or spec.uses_system_identity):
        system = identity.get("principalId")
        return "Search system-assigned identity", system if isinstance(system, str) and system else None
    wanted = spec.search_identity_resource_id.casefold()
    for key, value in (identity.get("userAssignedIdentities") or {}).items():
        if str(key).casefold() == wanted and isinstance(value, dict):
            principal = value.get("principalId")
            return "Search user-assigned identity", principal if isinstance(principal, str) and principal else None
    return "Search user-assigned identity", None


def _search_principals(arm: Any, spec: BuildSpec, search_observed: Any) -> list[tuple[str, str]]:
    """(label, principal ID) for every identity Search might call Content Understanding with."""
    principals = []
    identity = (search_observed.get("identity") or {}) if isinstance(search_observed, dict) else {}
    system = identity.get("principalId") if isinstance(identity, dict) else None
    if isinstance(system, str) and _GUID.fullmatch(system):
        principals.append(("Search system-assigned identity", system))
    if spec.search_identity_resource_id and not spec.uses_system_identity:
        observed = arm.arm_read(spec.search_identity_resource_id, IDENTITY_ARM_API_VERSION,
                                tenant_id=spec.tenant_id)
        assigned = ((observed or {}).get("properties") or {}).get("principalId")
        if not isinstance(assigned, str) or not _GUID.fullmatch(assigned):
            raise ValueError("Search user-assigned identity is unreadable")
        principals.append(("Search user-assigned identity", assigned))
    if not principals:
        raise ValueError("no Search identity is readable")
    return principals


def content_understanding_search_role(
    arm: Any, spec: BuildSpec, search_observed: Any,
) -> tuple[str, str | None] | None:
    """Read-only check that a Search identity holds a role on the CU account; never grants.

    A missing role otherwise shows up only when the indexer fails. The role counts when
    the system-assigned identity or the knowledge source's user-assigned identity holds
    it. Returns None when the check does not apply; status is present, missing,
    ambiguous or unknown.
    """
    if not _content_understanding_applies(arm, spec):
        return None
    endpoint = spec.target.content_understanding_endpoint
    try:
        account_id = _content_understanding_account(arm, spec)
        if not account_id:
            raise ValueError("Content Understanding account not found")
        principals = _search_principals(arm, spec, search_observed)
        held = [(label, principal, _roles_at(arm, spec, account_id, principal))
                for label, principal in principals]
    except Exception:  # unresolved, denied or malformed: report unverified, never fail
        return ("unknown",
                "CONTENT_UNDERSTANDING_ROLE_UNVERIFIED: could not read whether the Search "
                "identity holds Cognitive Services User on the Content Understanding account "
                f"at {endpoint}. Without it the indexer fails on PDFs, Office files and "
                f"images; confirm the role (see {CONTENT_UNDERSTANDING_DOC}).")
    account = account_id.rsplit("/", 1)[-1]
    if any(role in CONTENT_UNDERSTANDING_ROLES for _, _, roles in held for role in roles):
        return ("present", None)
    other = sorted({role for _, _, roles in held for role in roles
                    if role not in NOT_CONTENT_UNDERSTANDING_ROLES})
    if other:
        return ("ambiguous",
                "CONTENT_UNDERSTANDING_ROLE_UNCERTAIN: the Search identity holds role "
                f"definitions {', '.join(other)} on Content Understanding account {account} "
                "but not Cognitive Services User. If a custom role doesn't allow Content "
                "Understanding calls, the indexer fails on PDFs, Office files and images.")
    who = " nor the ".join(f"{label} {principal}" for label, principal, _ in held)
    who = f"neither the {who} holds" if len(held) > 1 else f"the {who} lacks"
    commands = "; ".join(
        f"az role assignment create --assignee-object-id {principal} --assignee-principal-type "
        f"ServicePrincipal --role \"Cognitive Services User\" --scope {account_id}"
        for _, principal, _ in held)
    return ("missing",
            f"CONTENT_UNDERSTANDING_ROLE_MISSING: {who} Cognitive Services "
            f"User on Content Understanding account {account}, so the indexer would fail on "
            "PDFs, Office files and images. Have the account owner run: "
            f"{commands}; then rerun (see {CONTENT_UNDERSTANDING_DOC}).")


def content_understanding_region(arm: Any, spec: BuildSpec) -> tuple[str, str | None] | None:
    """Read-only check that the CU account is in a Content Understanding region.

    Warns rather than blocks: the region list is a dated copy and Microsoft adds regions.
    Returns None when the check does not apply; status is supported, unsupported or unknown.
    """
    if not _content_understanding_applies(arm, spec):
        return None
    endpoint = spec.target.content_understanding_endpoint
    try:
        account_id = _content_understanding_account(arm, spec)
        if not account_id:
            raise ValueError("Content Understanding account not found")
        observed = arm.arm_read(account_id, COGNITIVE_ARM_API_VERSION, tenant_id=spec.tenant_id)
        location = observed.get("location") if isinstance(observed, dict) else None
        if not isinstance(location, str) or not location.strip():
            raise ValueError("account location is missing")
    except Exception:  # unresolved, denied or malformed: report unverified, never fail
        return ("unknown",
                "CONTENT_UNDERSTANDING_REGION_UNVERIFIED: could not read the region of the "
                f"Content Understanding account at {endpoint}; confirm it's a Content "
                "Understanding region.")
    if region_supported(location):
        return ("supported", None)
    return ("unsupported", region_warning("CONTENT_UNDERSTANDING_REGION_UNSUPPORTED",
                                          account_id.rsplit("/", 1)[-1], location))


def _identity(resource_id: str | None, provider: str, resource_type: str) -> tuple[str, str, str] | None:
    match = _ARM_ID.fullmatch(resource_id or "")
    if not match or not _GUID.fullmatch(match[1]) or (
        match[3].casefold(), match[4].casefold()
    ) != (provider.casefold(), resource_type.casefold()):
        return None
    return match[1], match[2], match[5]


def route(spec: BuildSpec) -> RouteDecision:
    outcome = spec.requested_outcome or RequestedOutcome.GRAPH_BUILD
    sharepoint = spec.source is not None and spec.source.kind is SourceKind.SHAREPOINT_LIBRARY
    kind = spec.knowledge_source_kind or (
        KnowledgeSourceKind.SHAREPOINT if sharepoint else KnowledgeSourceKind.AZURE_BLOB
    )
    if kind is not KnowledgeSourceKind.AZURE_BLOB or sharepoint:
        return RouteDecision(outcome, kind, "unsupported",
                             blocked_by=("UNSUPPORTED_GRAPH_ROUTE: graphExtraction is verified only on Azure Blob KS; no automatic source copy",))
    if spec.source is None:
        return RouteDecision(outcome, kind, "unsupported",
                             blocked_by=("SOURCE_REQUIRED: pass --source-kind and --source-reference, "
                                         "then inventory the source",))
    if spec.source_manifest is None:
        return RouteDecision(outcome, kind, "unsupported",
                             blocked_by=("SOURCE_MANIFEST_REQUIRED: run `entity-graph-build inventory` "
                                         "and pass its manifest as --source-manifest",))
    return RouteDecision(
        outcome, kind, "verified_path",
        evidence=(f"Search {search_api_version(spec)} Azure Blob graphExtraction via approved staging",),
    )


def target_blockers(spec: BuildSpec) -> tuple[str, ...]:
    target = spec.target
    errors: list[str] = []
    if target.search_resource_id is not None:
        try:
            expected_search = search_resource_id(spec)
        except ValueError:
            expected_search = None
        if (not isinstance(target.search_resource_id, str) or not expected_search
                or target.search_resource_id.casefold() != expected_search.casefold()):
            errors.append("TARGET_ID_MISMATCH: Search ARM ID differs from exact subscription, RG or endpoint")
    for label, resource_id, provider, kind, endpoint, suffix in (
        ("Storage", target.storage_resource_id, "Microsoft.Storage", "storageAccounts",
         target.storage_endpoint, "blob.core.windows.net"),
        ("OpenAI", target.openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.openai_endpoint, None),
        ("Embedding OpenAI", target.embedding_openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.effective_embedding_openai_endpoint, None),
        ("Chat OpenAI", target.chat_openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.effective_chat_openai_endpoint, None),
        ("KB OpenAI", target.kb_openai_resource_id, "Microsoft.CognitiveServices", "accounts",
         target.effective_kb_openai_endpoint, None),
    ):
        if resource_id is None:
            continue
        parsed = _identity(resource_id, provider, kind)
        if parsed is None:
            errors.append(f"TARGET_ID_MISMATCH: {label} ARM ID is invalid")
        elif label == "Storage" and endpoint != f"https://{parsed[2]}.{suffix}":
            errors.append("TARGET_ENDPOINT_MISMATCH: Storage endpoint differs from exact account ARM ID")
        elif label != "Storage" and (
            not isinstance(endpoint, str) or not endpoint.startswith("https://")
        ):
            errors.append(f"TARGET_ENDPOINT_MISMATCH: {label} endpoint is required with its ARM ID")
    if target.cache_storage_resource_id is not None:
        if _identity(target.cache_storage_resource_id, "Microsoft.Storage", "storageAccounts") is None:
            errors.append("TARGET_ID_MISMATCH: Cache Storage ARM ID is invalid")
    if spec.source and spec.source.kind is SourceKind.BLOB_PREFIX:
        parsed = _identity(spec.source.resource_id, "Microsoft.Storage", "storageAccounts")
        if parsed is None or spec.source.reference != f"https://{parsed[2]}.blob.core.windows.net":
            errors.append("SOURCE_ID_MISMATCH: Blob source endpoint differs from exact account ARM ID")
    return tuple(errors)


def scope(spec: BuildSpec, decision: RouteDecision | None) -> dict[str, Any]:
    from .executor import staging_prefix

    try:
        derived_search_id = search_resource_id(spec)
    except ValueError:
        derived_search_id = None
    direct_blob = uses_direct_blob_source(spec)
    storage_res_id = spec.target.storage_resource_id or (
        spec.source.resource_id if direct_blob and spec.source else None
    )
    storage_ep = spec.target.storage_endpoint or (
        spec.source.reference if direct_blob and spec.source else ""
    )
    storage_container = (
        spec.source.container if direct_blob and spec.source else spec.storage_container
    )
    prefix = (
        spec.source.prefix if direct_blob and spec.source else staging_prefix(spec)
    ) if (spec.source_manifest and spec.source) else None
    extra_openai: dict[str, Any] = {}
    for key in (
        "embedding_openai_resource_id", "embedding_openai_endpoint",
        "chat_openai_resource_id", "chat_openai_endpoint",
        "kb_openai_resource_id", "kb_openai_endpoint",
    ):
        val = getattr(spec.target, key, None)
        if val is not None:
            extra_openai[key] = val
    for spec_key in ("kb_chat_deployment", "kb_chat_model"):
        val = getattr(spec, spec_key, None)
        if val is not None:
            extra_openai[spec_key] = val
    return {
        "source_kind": spec.source.kind.value if spec.source else None,
        "source_id": spec.source.source_id if spec.source else None,
        "source_resource_id": spec.source.resource_id if spec.source else None,
        "manifest_digest": spec.source_manifest.digest if spec.source_manifest else None,
        "document_count": spec.source_manifest.document_count if spec.source_manifest else None,
        "requested_outcome": decision.outcome.value if decision else None,
        "knowledge_source_kind": decision.knowledge_source_kind.value if decision else None,
        "tenant_id": spec.tenant_id,
        "subscription_id": spec.target.subscription_id,
        "search_resource_id": spec.target.search_resource_id or derived_search_id,
        "storage_resource_id": storage_res_id,
        "openai_resource_id": spec.target.openai_resource_id,
        **({"cache_storage_resource_id": spec.target.cache_storage_resource_id}
           if spec.target.cache_storage_resource_id else {}),
        **extra_openai,
        **({
            "storage_container": storage_container,
            "staging_prefix": prefix,
            "search_endpoint": spec.target.search_endpoint,
            "storage_endpoint": storage_ep,
            "openai_endpoint": spec.target.openai_endpoint,
            **({"content_extraction": "content_understanding",
                "content_understanding_endpoint": spec.target.content_understanding_endpoint}
               if uses_content_understanding(spec) else {}),
        } if spec.source_manifest and spec.source else {}),
    }


def _observed_mismatch(blockers: list[str]) -> bool:
    return any(item.startswith((
        "TARGET_ID_MISMATCH:", "TARGET_ENDPOINT_MISMATCH:",
        "TARGET_SKU_MISMATCH:", "TARGET_REGION_MISMATCH:", "TARGET_NOT_READY:",
        "TENANT_MISMATCH:", "PERMISSION_DENIED:", "TARGET_INSPECTION_FAILED:",
    )) for item in blockers)


def preflight(spec: BuildSpec, reader: ResourceReader | None = None,
              arm: Any = None) -> PreflightResult:
    """`arm` (an adapter with tenant-checked `arm_read`) adds the advisory soft delete check."""
    from .planner import plan

    desired = plan(spec)
    decision = desired.route or route(spec)
    blockers = list(desired.blocked_by)
    unsupported = decision.capability == "unsupported"
    # A missing manifest is a readiness gap, not an unsupported route: still inspect targets read-only.
    awaiting_manifest = unsupported and bool(decision.blocked_by) and all(
        reason.startswith("SOURCE_MANIFEST_REQUIRED:") for reason in decision.blocked_by
    )
    route_closed = unsupported and not awaiting_manifest
    if unsupported:
        blockers.extend(reason for reason in (
            decision.blocked_by or ("UNSUPPORTED_ROUTE: no implemented route",)
        ) if reason not in blockers)
    evidence: dict[str, Any] = {
        "origin": "offline_contract",
        "capability": decision.capability,
    }
    uncertainties = list(decision.uncertainty)
    warnings: list[str] = []
    can_inspect = (
        reader is not None and not graph_input_error(spec) and not target_blockers(spec)
        and not route_closed
    )
    if can_inspect:
        expected = spec.target.search_resource_id or search_resource_id(spec)
        observed = reader.inspect_search_service(expected, spec.tenant_id)
        search_observed = observed
        evidence["origin"] = "injected_resource_observations"
        if not isinstance(observed, dict):
            blockers.append("TARGET_INSPECTION_FAILED: Search inspection did not return resource metadata")
        else:
            properties = observed.get("properties")
            sku = observed.get("sku")
            if (str(observed.get("id", "")).casefold() != expected.casefold()
                    or str(observed.get("name", "")).casefold() != expected.rsplit("/", 1)[-1].casefold()
                    or not isinstance(properties, dict)
                    or properties.get("endpoint") != spec.target.search_endpoint):
                blockers.append("TARGET_ID_MISMATCH: observed Search ARM identity or endpoint differs")
            elif not isinstance(sku, dict) or str(sku.get("name", "")).casefold() != str(spec.search_sku or "").casefold():
                blockers.append("TARGET_SKU_MISMATCH: observed Search SKU differs")
            elif str(observed.get("location", "")).replace(" ", "").casefold() != str(spec.target.location or "").casefold():
                blockers.append("TARGET_REGION_MISMATCH: observed Search region differs")
            elif str(properties.get("provisioningState", "")).casefold() != "succeeded":
                blockers.append("TARGET_NOT_READY: Search provisioning is not complete")
            if (observed.get("tenant_id") and
                    str(observed["tenant_id"]).casefold() != spec.tenant_id.casefold()
                    or spec.source_manifest and not observed.get("tenant_id")):
                blockers.append("TENANT_MISMATCH: observed tenant differs from requested tenant")
            if observed.get("permissions") == "denied":
                blockers.append("PERMISSION_DENIED: caller lacks required Search access")
            evidence["search_arm_observed"] = not _observed_mismatch(blockers)
            if not observed.get("tenant_id"):
                uncertainties.append("TENANT_UNVERIFIED: Search ARM resource does not attest tenant membership")
        direct_blob = uses_direct_blob_source(spec)
        storage_res_id = spec.target.storage_resource_id or (
            spec.source.resource_id if direct_blob and spec.source else None
        )
        storage_ep = spec.target.storage_endpoint or (
            spec.source.reference if direct_blob and spec.source else ""
        )
        resource_checks: list[tuple[str, str | None, str]] = [
            ("Storage", storage_res_id, storage_ep),
            ("OpenAI", spec.target.openai_resource_id, spec.target.openai_endpoint),
        ]
        for res_id, ep in (
            (spec.target.embedding_openai_resource_id, spec.target.effective_embedding_openai_endpoint),
            (spec.target.chat_openai_resource_id, spec.target.effective_chat_openai_endpoint),
            (spec.target.kb_openai_resource_id, spec.target.effective_kb_openai_endpoint),
        ):
            if res_id and ("OpenAI", res_id, ep) not in resource_checks:
                resource_checks.append(("OpenAI", res_id, ep))
        for label, resource_id, endpoint in resource_checks:
            if not resource_id or _observed_mismatch(blockers):
                continue
            if not hasattr(reader, "inspect_resource"):
                uncertainties.append(f"{label.upper()}_UNVERIFIED: no read-only resource reader is available")
                continue
            observed = reader.inspect_resource(resource_id, spec.tenant_id)
            if (not isinstance(observed, dict)
                    or str(observed.get("id", "")).casefold() != resource_id.casefold()
                    or not isinstance(observed.get("endpoint"), str)
                    or canonical_resource_endpoint(observed["endpoint"]) !=
                    canonical_resource_endpoint(endpoint)):
                blockers.append(f"TARGET_ID_MISMATCH: observed {label} ARM identity or endpoint differs")
            elif (observed.get("tenant_id") and
                  str(observed["tenant_id"]).casefold() != spec.tenant_id.casefold()
                  or spec.source_manifest and not observed.get("tenant_id")):
                blockers.append(f"TENANT_MISMATCH: observed {label} tenant differs")
            elif observed.get("permissions") == "denied":
                blockers.append(f"PERMISSION_DENIED: caller lacks required {label} access")
            elif label == "Storage" and not spec.target.cache_storage_resource_id and (
                observed.get("kind") and observed.get("kind") != "StorageV2"
            ):
                blockers.append("CACHE_STORAGE_KIND_INVALID: enrichment cache requires a StorageV2 (general-purpose v2) storage account")
            else:
                evidence[f"{label.lower()}_arm_observed"] = True
        cache_id = spec.target.cache_storage_resource_id or storage_res_id
        if (
            spec.target.cache_storage_resource_id
            and not _observed_mismatch(blockers)
            and hasattr(reader, "inspect_resource")
        ):
            cache_obs = reader.inspect_resource(
                spec.target.cache_storage_resource_id, spec.tenant_id
            )
            if (
                not isinstance(cache_obs, dict)
                or str(cache_obs.get("id", "")).casefold()
                != spec.target.cache_storage_resource_id.casefold()
            ):
                blockers.append("TARGET_ID_MISMATCH: observed Cache Storage ARM identity differs")
            elif cache_obs.get("kind") and cache_obs.get("kind") != "StorageV2":
                blockers.append(
                    "CACHE_STORAGE_KIND_INVALID: enrichment cache requires a StorageV2 "
                    "(general-purpose v2) storage account"
                )
            else:
                evidence["cache_storage_arm_observed"] = True
        if cache_id and not _observed_mismatch(blockers) and hasattr(reader, "inspect_cache_roles"):
            who_label, cache_principal = _cache_principal(spec, search_observed)
            if not cache_principal:
                blockers.append(
                    "CACHE_ROLES_MISSING: Search service has no system-assigned managed "
                    "identity for the enrichment cache; run entity-graph-provision connect"
                    if who_label == "Search system-assigned identity" else
                    f"CACHE_ROLES_MISSING: {who_label} is not attached to the Search service; "
                    "run entity-graph-provision connect"
                )
            else:
                missing_roles = reader.inspect_cache_roles(
                    cache_id, cache_principal, spec.tenant_id
                )
                if missing_roles:
                    blockers.append(
                        f"CACHE_ROLES_MISSING: {who_label} lacks {', '.join(missing_roles)} "
                        "on the cache storage account; run entity-graph-provision connect to grant them"
                    )
                else:
                    evidence["cache_roles_observed"] = True
        soft_delete = blob_soft_delete(arm, spec) if not _observed_mismatch(blockers) else None
        if soft_delete is not None:
            evidence["blob_soft_delete"] = soft_delete[0]
            if soft_delete[1]:
                warnings.append(soft_delete[1])
        cu_embedding = (content_understanding_embedding(arm, spec)
                        if not _observed_mismatch(blockers) else None)
        if cu_embedding is not None:
            evidence["content_understanding_embedding"] = cu_embedding[0]
            if cu_embedding[0] == "missing":
                blockers.append(cu_embedding[1])
            elif cu_embedding[0] == "unknown":
                uncertainties.append(cu_embedding[1])
            elif cu_embedding[1]:
                warnings.append(cu_embedding[1])
        cu_role = (content_understanding_search_role(arm, spec, search_observed)
                   if not _observed_mismatch(blockers) else None)
        if cu_role is not None:
            evidence["content_understanding_role"] = cu_role[0]
            if cu_role[0] == "missing":
                blockers.append(cu_role[1])
            elif cu_role[0] == "unknown":
                uncertainties.append(cu_role[1])
            elif cu_role[1]:
                warnings.append(cu_role[1])
        cu_region = (content_understanding_region(arm, spec)
                     if not _observed_mismatch(blockers) else None)
        if cu_region is not None:
            evidence["content_understanding_region"] = cu_region[0]
            if cu_region[0] == "unknown":
                uncertainties.append(cu_region[1])
            elif cu_region[1]:
                warnings.append(cu_region[1])
    elif not route_closed:
        uncertainties.append("TARGET_UNVERIFIED: no read-only resource observations were supplied")
    if not route_closed:
        uncertainties.append("PERMISSIONS_UNVERIFIED: ARM identity alone does not prove data-plane RBAC or network access")
    if spec.source is not None:
        uncertainties.append(
            "SOURCE_APPROVAL_RECHECK_REQUIRED: source bytes must be rechecked before staging"
            if spec.source_manifest else
            "SOURCE_NOT_INVENTORIED: provide an adapter-produced manifest for this route"
        )
    priority = next((item for item in blockers if item.startswith((
        "TARGET_ID_MISMATCH:", "TARGET_ENDPOINT_MISMATCH:",
        "TARGET_SKU_MISMATCH:", "TARGET_REGION_MISMATCH:", "TARGET_NOT_READY:",
        "TENANT_MISMATCH:", "PERMISSION_DENIED:", "SOURCE_ID_MISMATCH:",
    ))), None)
    if priority is None and unsupported:
        priority = decision.blocked_by[0] if decision.blocked_by else "UNSUPPORTED_ROUTE: no implemented route"
    if priority is None and blockers:
        priority = blockers[0]
    code = priority.split(":", 1)[0] if priority else "BUILD_PLAN_REQUIRES_APPROVAL"
    next_action = (
        "Inventory the source with its read-only adapter, attach its manifest, then request "
        "separate approval of the exact staged Azure Blob graph plan."
        if code == "SOURCE_MANIFEST_REQUIRED" else
        "Correct the exact source, target or route and rerun read-only preflight."
        if blockers else
        "Review the exact plan and remaining target/permission evidence; request separate approval before writes."
    )
    event = Event("preflight", "blocked" if blockers else "planned", code, {
        "plan_id": desired.plan_id, "blockers": blockers,
        "uncertainty": uncertainties, "evidence": evidence,
        **({"warnings": warnings} if warnings else {}),
    })
    return PreflightResult(desired.plan_id, "blocked" if blockers else "unverified", code, next_action,
                           decision, desired.scope or scope(spec, decision), (event,))
