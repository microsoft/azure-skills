"""Regions where Azure Content Understanding is available.

Provision warns when a Content Understanding account would land outside this list, and the
live Build preflight warns when an existing account is outside it. Neither blocks: Microsoft
adds regions, so a stale list must never stop a working account.
"""

from __future__ import annotations

# The account name becomes customSubDomainName and the https://<name>.services.ai.azure.com
# host, so it follows DNS label rules: alphanumerics and inner hyphens, no underscores.
ACCOUNT_NAME_PATTERN = r"[a-zA-Z0-9][a-zA-Z0-9-]{0,62}[a-zA-Z0-9]"

SUPPORTED_REGIONS_SOURCE = (
    "https://learn.microsoft.com/en-us/azure/ai-services/content-understanding/"
    "language-region-support"
)
# The date this list was copied from the source page (page last updated 2026-10-19).
SUPPORTED_REGIONS_CHECKED = "2026-11-13"
SUPPORTED_REGIONS = frozenset({
    "australiaeast", "canadacentral", "eastus", "eastus2", "japaneast", "southcentralus",
    "southeastasia", "swedencentral", "uksouth", "westeurope", "westus", "westus3",
})


def normalize_region(location: str) -> str:
    """ARM returns display names ("East US 2") or short names ("eastus2")."""
    return "".join(str(location).split()).casefold()


def region_supported(location: str) -> bool:
    return normalize_region(location) in SUPPORTED_REGIONS


def region_warning(code: str, account: str, location: str) -> str:
    return (
        f"{code}: Content Understanding account {account} is in {location}, which isn't in "
        f"the supported-region list checked on {SUPPORTED_REGIONS_CHECKED} "
        f"({', '.join(sorted(SUPPORTED_REGIONS))}; {SUPPORTED_REGIONS_SOURCE}). Standard "
        "extraction of PDFs, Office files and images can fail there. Use a supported region, "
        "or confirm on that page that the region was added since."
    )
