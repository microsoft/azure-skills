"""Per-user state folders that still work when the home directory isn't writable.

Sandboxed agent harnesses (Codex workspace-write, macOS seatbelt, Linux landlock) allow writes only to
the workspace and the temp folder. A home default is used only if a real create-and-write succeeds;
otherwise the folder moves to a private per-user folder under the temp directory, and one note goes to
stderr. An explicit override (ENTITY_HOME, TOPICGRAPH_HOME, ...) is used as given and never probed.

The same file ships in each graph runtime package, which are installed as separate wheels.
"""

from __future__ import annotations

import getpass
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile


class HomeError(RuntimeError):
    pass


_RESOLVED: dict[tuple[str, str], Path] = {}


def _user() -> str:
    try:
        name = getpass.getuser()
    except Exception:  # getuser raises OSError or KeyError when no login name is set
        name = str(os.getuid()) if hasattr(os, "getuid") else "user"
    return re.sub(r"[^A-Za-z0-9_.-]", "_", name) or "user"


def writable(path: Path) -> bool:
    """Create `path` if needed and write a probe file there; False on EPERM, EACCES or any other OSError."""
    try:
        path.mkdir(parents=True, exist_ok=True)
        handle, name = tempfile.mkstemp(prefix=".write-probe-", dir=path)
        os.close(handle)
        os.unlink(name)
    except OSError:
        return False
    return True


def _temp_root() -> Path:
    return Path(tempfile.gettempdir()) / f"foundry-iq-skills-{_user()}"


def private_temp_root() -> Path:
    """The per-user fallback folder under the temp directory, created 0700 and checked before use."""
    root = _temp_root()
    try:
        os.mkdir(root, 0o700)
    except FileExistsError:
        pass
    _check(root)
    return root


def _check(root: Path) -> None:
    info = os.lstat(root)
    if stat.S_ISLNK(info.st_mode) or not stat.S_ISDIR(info.st_mode) or getattr(root, "is_junction", bool)():
        raise HomeError(f"Refusing the temp folder {root}: it is a link or not a folder. Remove it, "
                        "or set the location explicitly.")
    if hasattr(os, "getuid"):
        if info.st_uid != os.getuid():
            raise HomeError(f"Refusing the temp folder {root}: another user owns it. "
                            "Set the location explicitly.")
        if stat.S_IMODE(info.st_mode) & 0o077:
            os.chmod(root, 0o700)


def check_subfolder(root: Path, name: str) -> None:
    """Refuse `<root>/<name>` if any part of it below `root` is a symlink, a junction or not a folder."""
    current = root
    for part in Path(name).parts:
        current = current / part
        if current.is_symlink() or getattr(current, "is_junction", bool)() or (
                os.path.lexists(current) and not current.is_dir()):
            raise HomeError(f"Refusing {current}: it is a link or not a folder. Remove it, "
                            "or set the location explicitly.")


def locate_home(default: Path, name: str) -> Path:
    """Where to read existing state without creating anything: the folder this process already chose,
    else `default` if it exists, else the private temp fallback if it exists and passes the checks."""
    if (chosen := _RESOLVED.get((str(default), name))) is not None:
        return chosen
    if default.exists():
        return default
    fallback = _temp_root() / name
    try:
        if fallback.exists():
            _check(_temp_root())
            check_subfolder(_temp_root(), name)
            return fallback
    except (OSError, HomeError):
        pass
    return default


def resolve_home(default: Path, name: str, variable: str, allowed: bool = True) -> Path:
    """`default` if it is `allowed` and can be created and written; otherwise `<private temp root>/<name>`.

    The answer is fixed for the life of the process, so readers and writers agree.
    """
    key = (str(default), name)
    if key in _RESOLVED:
        return _RESOLVED[key]
    if allowed and writable(default):
        path = default
    else:
        root = private_temp_root()
        check_subfolder(root, name)
        path = root / name
        try:
            path.mkdir(mode=0o700, parents=True, exist_ok=True)
        except OSError as exc:
            raise HomeError(f"Neither {default} nor {path} can be written. Set {variable} to a "
                            "writable folder.") from exc
        check_subfolder(root, name)
        if not writable(path):
            raise HomeError(f"Neither {default} nor {path} can be written. Set {variable} to a "
                            "writable folder.")
        reason = "isn't writable here" if allowed else "is inside a project folder that git doesn't ignore"
        print(f"Foundry IQ: {default} {reason}, so this session uses the private temp "
              f"folder {path}. Set {variable} to choose another location.", file=sys.stderr)
    _RESOLVED[key] = path
    return path


def git_ignored(path: Path, project: Path) -> bool:
    """True only when git says `path` is ignored in `project`, so nothing there can be committed or scanned."""
    git = shutil.which("git")
    if not git or not os.path.isabs(git):
        return False
    try:
        # The trailing separator lets folder-only patterns such as `.foundry-iq/` match a folder not yet created.
        return subprocess.run([git, "-C", str(project), "check-ignore", "-q", str(path) + os.sep],
                              stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                              timeout=10, check=False).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False
