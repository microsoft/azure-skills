"""Read-only GQL validation."""

from __future__ import annotations

import re

QUERY_MODES = frozenset({"traverse", "gql", "nl2gql", "kb"})
_LABEL = r"(?:`(?:[^`]|``)+`|[A-Za-z_]\w*)"
_LABELS = rf"{_LABEL}(?:\s*\|\s*{_LABEL})*"
_TYPED = r"(?:\s*:\s*|\s+(?i:IS)\s+)"
NODE_BINDING = rf"\(\s*(\w+)(?:{_TYPED}({_LABELS}))?\s*\)"
GRAPH_PATTERN = re.compile(
    rf"(?={NODE_BINDING}\s*(<-|-)\s*\[\s*(\w+)(?:{_TYPED}({_LABELS}))?\s*\]"
    rf"\s*(->|-)\s*{NODE_BINDING})")
_WRITES = re.compile(
    r"\b(?:CREATE|INSERT|DELETE|DETACH|SET|REMOVE|MERGE|UPDATE|DROP|ALTER|RENAME|"
    r"USE|CALL|LOAD|IMPORT|EXPORT|GRANT|REVOKE|UNION|NEXT|WITH|UNWIND|FOREACH|"
    r"SESSION|COMMIT|ROLLBACK)\b", re.IGNORECASE)


def query_mode(value: str | None) -> str:
    if value is None:
        return "traverse"
    if type(value) is not str or value not in QUERY_MODES:
        raise ValueError("query_mode must be traverse, nl2gql, gql or kb")
    return value


def mask_literals(query: str, *, preserve_identifiers: bool = False) -> str:
    masked = list(query)
    quote = None
    index = 0
    while index < len(query):
        char = query[index]
        if quote:
            if char in "\r\n\t":
                raise ValueError("query must not contain multiline string literals or identifiers")
            if quote != "`" or not preserve_identifiers:
                masked[index] = " "
            if char == "\\" and index + 1 < len(query) and query[index + 1] in (quote, "\\"):
                # The engine reads a backslash before a quote as an escape; '' is an escape too, so
                # the end of the literal is ambiguous. A doubled backslash reads the same either way.
                if query[index + 1] == quote:
                    raise ValueError("GQL must not escape a quote with a backslash; double the quote instead")
                if quote != "`" or not preserve_identifiers:
                    masked[index + 1] = " "
                index += 2
                continue
            if char == quote:
                if index + 1 < len(query) and query[index + 1] == quote:
                    if quote != "`" or not preserve_identifiers:
                        masked[index + 1] = " "
                    index += 1
                else:
                    quote = None
        elif char in "'\"`":
            quote = char
            if quote != "`" or not preserve_identifiers:
                masked[index] = " "
        index += 1
    if quote:
        raise ValueError("GQL contains an unterminated quoted literal or identifier")
    return "".join(masked)


def validate_query_text(query: str) -> None:
    """Bound any query text; GQL literal checks live in validate_readonly_gql."""
    if (type(query) is not str or not query.strip() or len(query) > 2048
            or any((ord(c) < 32 and c not in "\r\n\t") or ord(c) == 127 for c in query)):
        raise ValueError("query must be nonempty text of at most 2048 characters without control characters")


def validate_readonly_gql(query: str) -> None:
    validate_query_text(query)
    masked = mask_literals(query)
    clauses = re.sub(r"\b(?:STARTS|ENDS)\s+WITH\b", "", masked, flags=re.IGNORECASE)
    returned = re.search(r"\bRETURN\b", masked, re.IGNORECASE)
    if (";" in query or any(comment in masked for comment in ("//", "--", "/*", "*/"))
            or _WRITES.search(clauses)
            or not re.match(r"^\s*MATCH\b", masked, re.IGNORECASE)
            or len(re.findall(r"\bMATCH\b", masked, re.IGNORECASE)) != 1
            or len(re.findall(r"\bRETURN\b", masked, re.IGNORECASE)) != 1
            or returned is None or not query[returned.end():].strip()):
        raise ValueError("GQL must be a single read-only MATCH ... RETURN statement without comments or semicolons")


def label_names(binding: str | None) -> list[str]:
    return [label[1:-1].replace("``", "`") if label.startswith("`") else label
            for label in re.findall(_LABEL, binding or "")]
