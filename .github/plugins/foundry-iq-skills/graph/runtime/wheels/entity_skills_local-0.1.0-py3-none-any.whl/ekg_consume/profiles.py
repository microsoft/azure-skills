"""Dataset profiles: corpus-specific consume behavior kept out of the generic query path.

The base ``DatasetProfile`` is the neutral profile every graph gets by default: predicates are
humanized by splitting their words, questions are not scoped to source files, and question words
imply no ontology classes. A dataset whose corpus has known conventions (such as one transcript per
earnings call) ships a subclass, selected explicitly by ``endpoints.dataset_profile`` in the
descriptor or by the ``ENTITY_CONSUME_PROFILE`` environment variable.
"""

from __future__ import annotations

from collections.abc import Mapping
import importlib
import os
from typing import Any

PROFILE_ENV = "ENTITY_CONSUME_PROFILE"
_PROFILES = {
    "microsoft-earnings-calls": (
        "ekg_consume.dataset_profiles.microsoft_earnings_calls", "EarningsCallsProfile"),
}
_LOADED: dict[str, DatasetProfile] = {}


class DatasetProfile:
    """Neutral consume behavior. Subclasses override only what their corpus needs."""

    name = "neutral"
    # Lowercased predicate -> plural noun used in hub labels ("acquiredby" -> "acquisitions").
    predicate_labels: Mapping[str, str] = {}
    # Lowercased class name -> plural used in starter questions.
    type_plurals: Mapping[str, str] = {}
    # (question words, ontology classes those words imply).
    class_hints: tuple[tuple[frozenset[str], tuple[str, ...]], ...] = ()
    person_classes: frozenset[str] = frozenset({"Person", "People"})
    person_words: frozenset[str] = frozenset({"person", "people"})
    # Lowercased predicates sampled first for starter questions, in order.
    starter_predicates: tuple[str, ...] = ()
    # Lowercased target classes sampled last for starter questions.
    deprioritized_targets: frozenset[str] = frozenset()

    @property
    def hint_words(self) -> frozenset[str]:
        return frozenset(word for words, _ in self.class_hints for word in words)

    def source_filters(self, text: Any) -> list[str]:
        """Source filenames a text names, for scoping retrieval to those sources."""
        return []

    def period_seeds(self, query: str) -> list[str]:
        """Entity names for the period a question names, tried when its own names find nothing."""
        return []

    def scope_label(self, docs: list[str]) -> str:
        return ", ".join(docs)

    def mismatched_sources(self, statements: list[Any], docs: list[str]) -> list[str]:
        """Sources named in executed graph queries that the question didn't name."""
        return []

    def scope_graph(self, docs: list[str], nodes: dict[str, dict[str, Any]],
                    edges: dict[str, dict[str, Any]], paths: list[list[str]]) -> list[str]:
        """Keep only graph facts evidenced by ``docs``, in place; returns warnings."""
        return []

    def discover_starters(self, descriptor: dict[str, Any], client: Any,
                          labels: list[tuple[str, str, str]], graph_index: str,
                          ) -> list[dict[str, Any]] | None:
        """Dataset starter questions, or None to use the generic hub starters."""
        return None

    def match_starter(self, query: str, starters: list[dict[str, Any]]) -> dict[str, Any] | None:
        """A starter that answers a question phrased differently from it, if any."""
        return None


NEUTRAL = DatasetProfile()


def resolve_profile(descriptor: Mapping[str, Any] | None = None,
                    name: str | DatasetProfile | None = None) -> DatasetProfile:
    """The profile named explicitly, else by the descriptor, else by the environment."""
    if isinstance(name, DatasetProfile):
        return name
    selected = name
    if selected is None:
        endpoints = (descriptor or {}).get("endpoints")
        if isinstance(endpoints, Mapping):
            selected = endpoints.get("dataset_profile")
    if selected is None:
        selected = os.environ.get(PROFILE_ENV)
    if selected is not None and not isinstance(selected, str):
        raise ValueError("dataset_profile must be a string")
    key = (selected or "").strip().casefold()
    if not key or key == NEUTRAL.name:
        return NEUTRAL
    if key not in _PROFILES:
        known = ", ".join([NEUTRAL.name, *sorted(_PROFILES)])
        raise ValueError(f"Unknown dataset profile {selected!r}; choose from {known}")
    if key not in _LOADED:
        module_name, class_name = _PROFILES[key]
        _LOADED[key] = getattr(importlib.import_module(module_name), class_name)()
    return _LOADED[key]


def profile_names() -> tuple[str, ...]:
    return (NEUTRAL.name, *sorted(_PROFILES))
