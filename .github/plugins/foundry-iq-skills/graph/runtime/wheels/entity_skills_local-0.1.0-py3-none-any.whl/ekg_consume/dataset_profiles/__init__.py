"""Consume profiles for the packaged sample datasets. Each module is imported only when selected."""
