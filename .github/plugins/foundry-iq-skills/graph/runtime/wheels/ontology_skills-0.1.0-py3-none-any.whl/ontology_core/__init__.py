"""Shared core for ontology-skills: errors, output, hashing, state, journal and the ontology model."""

from __future__ import annotations

import functools
import os
import re
from pathlib import Path
from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("ontology-skills")
except PackageNotFoundError:  # running from a source tree without an install
    __version__ = "0.0.0"

SKILL_VERSION_PLACEHOLDER = "0.0.0-placeholder"


def skill_version() -> str:
    """``metadata.version`` of the installed foundry-iq skill, which release packaging stamps.

    The User-Agent reports the skill release, not this wheel's version. Without an installed
    plugin root (a source checkout or tests) it is the source placeholder.
    """
    root = os.environ.get("PLUGIN_ROOT") or os.environ.get("CLAUDE_PLUGIN_ROOT")
    return _read_skill_version(root) if root else SKILL_VERSION_PLACEHOLDER


@functools.lru_cache(maxsize=4)
def _read_skill_version(root: str) -> str:
    try:
        lines = (Path(root) / "skills" / "foundry-iq" / "SKILL.md").read_text(encoding="utf-8").splitlines()
    except (OSError, UnicodeError):
        return SKILL_VERSION_PLACEHOLDER
    if not lines or lines[0].strip() != "---":
        return SKILL_VERSION_PLACEHOLDER
    in_metadata = False
    for line in lines[1:]:
        if line.strip() == "---":
            break
        if not line[:1].isspace():
            in_metadata = line.split("#", 1)[0].strip() == "metadata:"
            continue
        key, _, value = line.split("#", 1)[0].strip().partition(":")
        if in_metadata and key == "version":
            value = value.strip().strip("\"'")
            if re.fullmatch(r"[0-9A-Za-z.+-]+", value):
                return value
    return SKILL_VERSION_PLACEHOLDER


# The foundry-iq live-validation token. Search telemetry filters test traffic on it.
TEST_TRAFFIC_MARKER = "foundry-iq-skill-live-v1"


def is_test_traffic() -> bool:
    """True when a test harness put ``TEST_TRAFFIC_MARKER`` in ``AZURE_HTTP_USER_AGENT``, as the core one does."""
    return TEST_TRAFFIC_MARKER in os.environ.get("AZURE_HTTP_USER_AGENT", "").split()


def skill_user_agent(*, env_appended: bool = False) -> str:
    """HTTP User-Agent attribution token per the foundry-iq http-contract.md.

    Test traffic also carries ``TEST_TRAFFIC_MARKER``, exactly once per request. Pass
    ``env_appended=True`` when the transport already appends ``AZURE_HTTP_USER_AGENT``
    (``az rest`` and azure-core's ``user_agent=``), so the marker isn't sent twice.
    """
    token = f"foundry-iq-skill-v{skill_version()}"
    return f"{token} {TEST_TRAFFIC_MARKER}" if is_test_traffic() and not env_appended else token


__all__ = ["TEST_TRAFFIC_MARKER", "__version__", "is_test_traffic", "skill_user_agent", "skill_version"]
